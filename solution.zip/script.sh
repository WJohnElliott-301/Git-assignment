#!/bin/bash
echo "Running solution data processing..."
if [ -f "input.txt" ]; then
    cat input.txt | grep -v "^#"
else
    echo "Input file not found!"
fi
